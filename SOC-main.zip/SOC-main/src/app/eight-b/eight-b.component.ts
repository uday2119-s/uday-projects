import { Component } from '@angular/core';
import {BookComponent} from '../book/book.component'
@Component({
  selector: 'app-eight-b',
  standalone: true,
  imports: [BookComponent],
  templateUrl: './eight-b.component.html',
  styleUrl: './eight-b.component.css'
})
export class EightBComponent {

}
