export class Book2 {
    id!: number;
    title!:string;
    author!: string;
}
