import { Component } from '@angular/core';

@Component({
  selector: 'app-seven-b',
  standalone: true,
  imports: [],
  templateUrl: './seven-b.component.html',
  styleUrl: './seven-b.component.css'
})
export class SevenBComponent {

}
