import { Component } from '@angular/core';
import { LoginComponent } from '../login/login.component';
@Component({
  selector: 'app-ten-b',
  standalone: true,
  imports: [LoginComponent],
  templateUrl: './ten-b.component.html',
  styleUrl: './ten-b.component.css'
})
export class TenBComponent {

}
