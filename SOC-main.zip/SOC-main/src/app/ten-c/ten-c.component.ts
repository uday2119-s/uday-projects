import { Component } from '@angular/core';
import { LoginComponent } from '../login/login.component';
@Component({
  selector: 'app-ten-c',
  standalone: true,
  imports: [LoginComponent],
  templateUrl: './ten-c.component.html',
  styleUrl: './ten-c.component.css'
})
export class TenCComponent {

}
