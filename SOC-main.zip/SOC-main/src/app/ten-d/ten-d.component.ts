import { Component } from '@angular/core';
import {BooksRoutingModule} from '../books/books-routing.module'
@Component({
  selector: 'app-ten-d',
  standalone: true,
  imports: [BooksRoutingModule],
  templateUrl: './ten-d.component.html',
  styleUrl: './ten-d.component.css'
})
export class TenDComponent {

}
